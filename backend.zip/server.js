const express = require('express');
const AWS = require('aws-sdk');
const multer = require('multer');
const ffmpeg = require('fluent-ffmpeg');
const fs = require('fs');
const path = require('path');
const { getSignedUrl } = require('aws-cloudfront-sign');
const cors = require('cors');


const ffmpegPath = 'C:\\ffmpeg\\bin\\ffmpeg.exe';
ffmpeg.setFfmpegPath(ffmpegPath);

const app = express();
const port = 3000;

app.use(cors({
    origin: 'http://localhost:3001',
    credentials: true
}));
app.use(express.static('output'));

// CORS middleware
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', 'http://localhost:3001');
    res.header('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    }
    next();
});

// Configure AWS S3


// CloudFront settings


// Multer setup for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

// Endpoint to handle video uploads
app.post('/upload', upload.single('video'), (req, res) => {
    const filePath = req.file.path;

    // Segment the video using ffmpeg
    ffmpeg(filePath)
        .outputOptions([
            '-hls_time 30', // Segment length
            '-hls_playlist_type vod'
        ])
        .output('./output/output.m3u8')
        .on('end', async () => {
            // Upload segments and m3u8 file to S3
            const uploadToS3 = (file) => {
                return new Promise((resolve, reject) => {
                    const fileStream = fs.createReadStream(file);
                    const params = {
                        Bucket: 'newtestbucketmedia',
                        Key: path.basename(file),
                        Body: fileStream,
                    };

                    s3.upload(params, (err, data) => {
                        if (err) {
                            reject(err);
                        }
                        resolve(data);
                    });
                });
            };

            const files = fs.readdirSync('output/');
            const uploadPromises = files.map((file) => uploadToS3(path.join('output', file)));

            try {
                await Promise.all(uploadPromises);

                // Generate signed URLs for each segment and m3u8 file
                // const signedUrls = files.map(file => {
                //     const url = `${cloudFrontUrl}${path.basename(file)}`;
                //     return getSignedUrl(url, {
                //         keypairId: keyPairId,
                //         privateKeyString: privateKey.toString(),
                //         expireTime: Date.now() + 60 * 60 * 1000 // 1 hour expiration
                //     });
                // });

                res.status(200).json({
                    message: 'Files uploaded successfully!',
                    urls: []
                });
            } catch (err) {
                res.status(500).send(err);
            }
        })
        .run();
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
