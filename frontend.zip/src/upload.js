import React, { useState } from 'react';
import axios from 'axios';

const VideoUpload = () => {
    const [selectedFile, setSelectedFile] = useState(null);
    const [videoUrls, setVideoUrls] = useState([]);

    const handleFileChange = (event) => {
        setSelectedFile(event.target.files[0]);
    };

    const handleUpload = async () => {
        const formData = new FormData();
        formData.append('video', selectedFile);
        console.log(selectedFile)
        return;

        try {
            const response = await axios.post('http://localhost:3000/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            setVideoUrls(response.data.urls);
            alert('File uploaded successfully');
        } catch (error) {
            console.error('Error uploading file:', error);
            alert('Error uploading file');
        }
    };

    return (
        <div>
            <input type="file" onChange={handleFileChange} />
            <button onClick={handleUpload}>Upload Video</button>
            {videoUrls.length > 0 && (
                <div>
                    <h2>Video URLs:</h2>
                    <ul>
                        {videoUrls.map((url, index) => (
                            <li key={index}><a href={url} target="_blank" rel="noopener noreferrer">{url}</a></li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default VideoUpload;
