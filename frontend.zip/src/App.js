

import Upload from "./upload"
import VideoJS from "./videoPlayer"
import ReactPlayer from 'react-player/youtube'
import React, { useState, useEffect } from 'react';

import axios from 'axios';

const App = () => {
  const [message, setMessage] = useState('');


    const url = "https://d1o0lc5l5pia87.cloudfront.net/output.m3u8";
  const imageUrl = "https://d1o0lc5l5pia87.cloudfront.net/Untitled_Export_V1.jpeg";

  const playerRef = React.useRef(null);

  const videoJsOptions = {
    controls: true,
    responsive: true,
    fluid: true,
    sources: [{
      src: url,
      type: 'application/x-mpegURL',
      withCredentials: true
    }]
  };

  const handlePlayerReady = (player) => {
    playerRef.current = player;

    // You can handle player events here, for example:
    player.on('waiting', () => {
      console.log('player is waiting');
    });

    player.on('dispose', () => {
      console.log('player will dispose');
    });
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:7000/api/v1/videos/signed-cookies',{withCredentials: true});
        console.log(response.data)
        setMessage(response.data.message);
      } catch (error) {
        console.error('Error:', error);
      }
    };

    // fetchData();
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <h1>CloudFront Signed Cookies Example</h1>
        <p>{message}</p>
        <Upload />
        <div>Rest of app here</div>
        {/* <ReactPlayer url={url} /> */}
        {/* <VideoJS options={videoJsOptions} onReady={handlePlayerReady} /> */}
        <VideoJS src={url} />
        {/* <video width="400" controls withCredentials>         
          <source src={url} type="video/mp4" />         
          Your browser does not support HTML5 video.       
        </video> */}
        <img src={imageUrl} className="App-logo" alt="logo" style={{ width: '30%' }} />
      </header>
    </div>
  );
};

export default App;

